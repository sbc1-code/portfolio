import os

from .base import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# Public example for local reproduction only; production has no fallback.
SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "local-demo-only-not-for-deployment")

# SECURITY WARNING: define the correct hosts in production!
ALLOWED_HOSTS = ["localhost", "127.0.0.1", "testserver"]

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"


try:
    from .local import *
except ImportError:
    pass
