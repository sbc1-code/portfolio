# Community Brief Studio: local Wagtail publication proof

Independent application sample for Codeword's Strategic Communications & Web Project Manager contract. All Cedar County material is fictional. Public Microsoft and AWS links are background examples for topic selection; they are not project evidence, endorsements, or an identified Codeword client.

## What is real

This is a real Django/Wagtail application using **Wagtail 8.0.1**, Django 6.1.2, Python 3.13, and SQLite. `home.CommunityBriefPage` is a Wagtail `Page` subclass with editable market fields and source/resource catalogues. Wagtail stores its drafts and revision history. The market page and print one-pager both render that same published record. The JSON import uses a transaction and Wagtail's `save_revision()` / `Revision.publish()` methods.

The proof is exercised through Django's HTTP test client, without a running web server. No user accounts or credentials were created. No Wagtail editor UI was opened. There is no hosted CMS, real client material, or claim of prior professional Wagtail experience. The separate public-facing portfolio prototype is not connected to this local database.

Built with Codex on October 27, 2026 for this application. The custom model, importer, templates, publication proof, and tests were created and run for the sample. This demonstrates the implementation described here; it does not establish earlier professional Wagtail experience.

## Reproduce

From this directory, with Python 3.13 available:

```sh
python3.13 -m venv .venv
.venv/bin/pip install -r requirements.lock.txt
.venv/bin/python manage.py migrate --noinput
.venv/bin/python manage.py test home --verbosity 1
.venv/bin/python manage.py prove_publication ../codeword-sample/content.json --output-dir evidence
```

The shared input lives at `../codeword-sample/content.json`. To use a different location, pass its local JSON path to the commands. No source URL is fetched by the application.

`manage.py` uses local development settings. Their clearly labeled example secret is for local reproduction only. WSGI defaults to production settings, which require a private `DJANGO_SECRET_KEY` environment value and configured `DJANGO_ALLOWED_HOSTS`. These settings are not a reviewed deployment configuration; no deployment is supplied or claimed.

To import as a draft only:

```sh
.venv/bin/python manage.py import_community_brief ../codeword-sample/content.json
```

To explicitly publish the imported revision:

```sh
.venv/bin/python manage.py import_community_brief ../codeword-sample/content.json --publish
```

Existing content is loaded as a revision object. It is not saved over the live database record before publication. New pages start with `live=False` and return HTTP 404 until published. Source IDs and resource references are validated before the transaction commits. The import does not infer approval from comments or claim to implement a human review workflow.

## Publication evidence

`evidence/publication-proof.json` records actual versions, input SHA-256, page and revision IDs, HTTP paths, checks, and rendered-output hashes.

The `prove_publication` command:

1. Imports and publishes the shared baseline contract.
2. Saves a changed construction sentence as a Wagtail draft revision.
3. Fetches both routes and verifies their HTML is byte-for-byte unchanged.
4. Publishes that draft and verifies the new sentence appears in both outputs.
5. Restores the original content as a new revision, republishes it, and verifies both outputs match the original. The intervening revisions remain in history.

HTML snapshots are exported for all four stages; `published-contract.json` contains the restored live content without internal comments. The database is left with the original shared content published. Running the proof again adds history; it does not delete previous revisions.

Four focused tests additionally verify new-draft visibility, private-comment exclusion, invalid-reference rollback, and HTML escaping. There is no claim of browser visual review, physical printing/pagination, assistive-technology testing, or Wagtail admin interaction. The print output is HTML with print CSS, not a prevalidated PDF.

## Content contract and implementation

Version 1 uses a `market` object with string fields `id`, `name`, `phase`, `updated`, `summary`, `construction`, `water`, `power`, `jobs`, `contact`, and `owner`; `sources` and `resources` are arrays; `comments` are internal context. `content_owner` is the local model field for the contract's `owner`, because Wagtail's base Page already uses `owner` for its user relation. Source records retain title, URL and context. Resource `sourceIds` must resolve to that catalogue.

Files of interest:

- `home/models.py`: actual Page model, Wagtail editor panels, validation, shared rendering.
- `home/content_import.py`: transactional draft import.
- `home/management/commands/prove_publication.py`: executable proof and evidence export.
- `home/tests.py`: focused publication and data-safety tests.
- `home/templates/home/community_brief_page.html` and `one_pager.html`: published output templates.
- `requirements.lock.txt`: installed dependency versions; no virtual environment or database should be distributed.

## Owning sources consulted

Checked October 27, 2026; official stable documentation identified itself as **8.0.1**:

- [Wagtail first-site tutorial](https://docs.wagtail.org/en/stable/getting_started/tutorial.html)
- [Wagtail model reference: revisions, publication, and recovery](https://docs.wagtail.org/en/stable/reference/models.html)
- [Wagtail 8.0 release notes](https://docs.wagtail.org/en/stable/releases/8.0.html)
- [Official role](https://job-boards.greenhouse.io/codeword/jobs/5444206008)

The Django/Wagtail project scaffold was generated with `wagtail start`. The recorded evidence covers local publication behavior only. Source cleanup and configuration checks do not change the earlier publication manifest or imply a public deployment.

## Distribution

Include source, migrations, dependency lists, this README, `evidence/`, and the shared content JSON. Exclude `.venv/`, databases (`*.sqlite3`, journals, `*.db`), `__pycache__/`, `*.pyc`, `.env*`, `cms/settings/local.py`, `media/`, and the collected-static root `static/`. Keep source assets under `cms/static/` and `home/static/`. No credentials, local database, or virtual environment is required in a public source bundle.
