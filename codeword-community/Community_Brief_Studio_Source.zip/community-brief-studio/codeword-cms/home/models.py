from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import URLValidator
from django.template.response import TemplateResponse
from wagtail.admin.panels import FieldPanel, MultiFieldPanel
from wagtail.contrib.routable_page.models import RoutablePageMixin, route
from wagtail.models import Page


class HomePage(Page):
    pass


class CommunityBriefPage(RoutablePageMixin, Page):
    """One revisioned record supplies the market page and print one-pager."""

    template = "home/community_brief_page.html"
    parent_page_types = ["home.HomePage"]
    subpage_types = []
    market_id = models.SlugField(unique=True)
    phase = models.CharField(max_length=120)
    market_updated = models.CharField(max_length=40)
    summary = models.TextField()
    construction = models.TextField()
    water = models.TextField()
    power = models.TextField()
    jobs = models.TextField()
    contact = models.TextField()
    content_owner = models.CharField(max_length=200)
    sources = models.JSONField(default=list)
    resources = models.JSONField(default=list)
    internal_comments = models.JSONField(default=list, blank=True)
    contract_version = models.PositiveSmallIntegerField(default=1)

    content_panels = Page.content_panels + [
        MultiFieldPanel([
            FieldPanel("market_id"), FieldPanel("phase"),
            FieldPanel("market_updated"), FieldPanel("content_owner"),
        ], heading="Market and editorial ownership"),
        MultiFieldPanel([
            FieldPanel("summary"), FieldPanel("construction"),
            FieldPanel("water"), FieldPanel("power"),
            FieldPanel("jobs"), FieldPanel("contact"),
        ], heading="Community brief — fictional demonstration content"),
        MultiFieldPanel([
            FieldPanel("sources"), FieldPanel("resources"),
        ], heading="Public reference catalogue and linked resources"),
        FieldPanel("internal_comments", heading="Internal context (never rendered publicly)"),
    ]

    def clean(self):
        super().clean()
        errors = {}
        if not isinstance(self.sources, list) or not isinstance(self.resources, list):
            raise ValidationError("Sources and resources must be JSON lists.")
        ids = []
        for source in self.sources:
            if not isinstance(source, dict) or not all(source.get(k) for k in ("id", "title", "url", "context")):
                errors["sources"] = "Each source requires id, title, url, and context."
                continue
            ids.append(source["id"])
            try:
                URLValidator(schemes=["https", "http"])(source["url"])
            except ValidationError:
                errors["sources"] = "Source URLs must use HTTP or HTTPS."
        if len(ids) != len(set(ids)):
            errors["sources"] = "Source IDs must be unique."
        for resource in self.resources:
            if not isinstance(resource, dict) or not all(resource.get(k) for k in ("id", "title", "topic", "summary")):
                errors["resources"] = "Each resource requires id, title, topic, and summary."
                continue
            refs = resource.get("sourceIds", [])
            if not isinstance(refs, list) or not set(refs).issubset(ids):
                errors["resources"] = "Resource sourceIds must refer to the source catalogue."
        if errors:
            raise ValidationError(errors)

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)
        context["brief_sections"] = self.brief_sections()
        return context

    def brief_sections(self):
        return [("Construction and nearby activity", self.construction),
                ("Water: what is known", self.water),
                ("Power: what is known", self.power),
                ("Jobs and local opportunities", self.jobs)]

    @route(r"^one-pager/$", name="one_pager")
    def one_pager(self, request):
        return TemplateResponse(request, "home/one_pager.html", {
            "page": self, "brief_sections": self.brief_sections(),
        })

    def as_contract(self):
        return {
            "version": self.contract_version,
            "market": {"id": self.market_id, "name": self.title, "phase": self.phase,
                       "updated": self.market_updated, "summary": self.summary,
                       "construction": self.construction, "water": self.water,
                       "power": self.power, "jobs": self.jobs,
                       "contact": self.contact, "owner": self.content_owner},
            "sources": self.sources, "resources": self.resources,
        }
