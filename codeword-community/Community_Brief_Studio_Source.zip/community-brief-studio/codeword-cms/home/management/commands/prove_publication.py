"""Exercise real Wagtail revision semantics, then export the evidence."""
import copy
import hashlib
import json
import platform
from pathlib import Path
from datetime import datetime, timezone
import django
import wagtail
from django.core.management.base import BaseCommand, CommandError
from django.test import Client
from home.content_import import import_content, load_content
from home.models import CommunityBriefPage


class Command(BaseCommand):
    help = "Prove draft isolation, publish consistency, and revision recovery without starting a server."

    def add_arguments(self, parser):
        parser.add_argument("path", type=Path)
        parser.add_argument("--output-dir", type=Path, default=Path("evidence"))

    def handle(self, *args, **options):
        payload = load_content(options["path"])
        out = options["output_dir"]
        out.mkdir(parents=True, exist_ok=True)
        page, original, _ = import_content(payload, publish=True)
        page = CommunityBriefPage.objects.get(pk=page.pk)
        urls = {"market": page.url, "one-pager": page.url + "one-pager/"}
        client = Client()

        def capture(label):
            responses = {name: client.get(url) for name, url in urls.items()}
            for name, response in responses.items():
                if response.status_code != 200:
                    raise CommandError(f"{label}/{name} returned {response.status_code}.")
                (out / f"{label}-{name}.html").write_bytes(response.content)
            return {name: response.content.decode() for name, response in responses.items()}

        baseline = capture("01-original-published")
        changed = copy.deepcopy(payload)
        changed["market"]["construction"] = "Demonstration revision: construction details remain unconfirmed. No work schedule has been announced."
        _, draft, _ = import_content(changed, publish=False)
        draft_capture = capture("02-draft-isolated")
        isolated = all(draft_capture[name] == baseline[name] for name in urls)
        draft.publish()
        published = capture("03-change-published")
        new_text = changed["market"]["construction"]
        consistent = all(new_text in html for html in published.values())
        old_revision = original.as_object()
        recovered = old_revision.save_revision(previous_revision=original)
        recovered.publish(previous_revision=original)
        restored = capture("04-original-restored")
        restored_equal = all(restored[name] == baseline[name] for name in urls)
        history_preserved = all(CommunityBriefPage.objects.get(pk=page.pk).revisions.filter(pk=r.pk).exists()
                                for r in (original, draft, recovered))
        checks = {"unpublished_draft_does_not_leak": isolated,
                  "publish_changes_both_outputs": consistent,
                  "previous_revision_recoverable": restored_equal,
                  "revision_history_preserved": history_preserved}
        if not all(checks.values()):
            raise CommandError(f"Publication proof failed: {checks}")
        live_page = CommunityBriefPage.objects.get(pk=page.pk)
        contract = live_page.as_contract()
        contract_json = json.dumps(contract, indent=2, ensure_ascii=False) + "\n"
        (out / "published-contract.json").write_text(contract_json, encoding="utf-8")
        manifest = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "scope": "Local Wagtail proof only; no server, accounts, external writes, or client material.",
            "versions": {"python": platform.python_version(), "django": django.get_version(), "wagtail": wagtail.__version__},
            "input_sha256": hashlib.sha256(options["path"].read_bytes()).hexdigest(),
            "page": {"id": page.pk, "model": "home.CommunityBriefPage", "market_id": page.market_id},
            "revisions": {"original": original.pk, "changed_draft_then_published": draft.pk, "recovered_as_new_revision": recovered.pk},
            "checks": checks,
            "http_paths": urls,
            "artifact_sha256": {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(out.glob("*.html"))},
            "limits": ["No Wagtail admin UI was opened or tested.", "No superuser or login credentials were created.",
                       "No public CMS is hosted.", "No device, visual, print pagination, or assistive-technology review is claimed."],
        }
        (out / "publication-proof.json").write_text(json.dumps(manifest, indent=2) + "\n")
        self.stdout.write(json.dumps({"checks": checks, "evidence_directory": str(out.resolve())}, indent=2))
