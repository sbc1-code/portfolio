from pathlib import Path
from django.core.management.base import BaseCommand, CommandError
from django.core.exceptions import ValidationError
from home.content_import import import_content, load_content


class Command(BaseCommand):
    help = "Import the shared local content contract as a Wagtail draft (or explicitly publish)."

    def add_arguments(self, parser):
        parser.add_argument("path", type=Path)
        parser.add_argument("--publish", action="store_true")

    def handle(self, *args, **options):
        try:
            page, revision, created = import_content(load_content(options["path"]), options["publish"])
        except (OSError, ValueError, ValidationError) as error:
            raise CommandError(str(error)) from error
        self.stdout.write(f"page={page.pk} revision={revision.pk} created={created} published={options['publish']}")
