"""Strict local JSON import; sources are stored and never fetched."""
import json
from django.core.exceptions import ValidationError
from django.db import transaction
from .models import CommunityBriefPage, HomePage


@transaction.atomic
def import_content(payload, publish=False):
    if payload.get("version") != 1 or not isinstance(payload.get("market"), dict):
        raise ValidationError("Expected the version 1 Community Brief content contract.")
    market = payload["market"]
    required = ("id", "name", "phase", "updated", "summary", "construction", "water", "power", "jobs", "contact", "owner")
    if any(key not in market or not isinstance(market[key], str) or not market[key].strip() for key in required):
        raise ValidationError("All version 1 market fields must be non-empty strings.")
    page = CommunityBriefPage.objects.filter(market_id=market["id"]).first()
    created = page is None
    if created:
        page = CommunityBriefPage(title=market["name"], slug=market["id"], market_id=market["id"], live=False)
    else:
        # Editing a revision object preserves the currently published database row.
        page = page.get_latest_revision_as_object()
    page.title = market["name"]
    for key in ("phase", "summary", "construction", "water", "power", "jobs", "contact"):
        setattr(page, key, market[key])
    page.content_owner = market["owner"]
    page.market_updated = market["updated"]
    page.sources = payload.get("sources", [])
    page.resources = payload.get("resources", [])
    page.internal_comments = payload.get("comments", [])
    page.contract_version = payload["version"]
    # Treebeard assigns these only when the new page is inserted below HomePage.
    page.full_clean(exclude=["path", "depth"] if created else None)
    if created:
        HomePage.objects.first().add_child(instance=page)
    revision = page.save_revision()
    if publish:
        revision.publish()
    return page, revision, created


def load_content(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)
