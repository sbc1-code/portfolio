import copy
from django.core.exceptions import ValidationError
from django.test import TestCase
from home.content_import import import_content
from home.models import CommunityBriefPage


def sample():
    return {
        "version": 1,
        "market": {"id": "cedar-county", "name": "Cedar County", "phase": "Planning — fictional example",
                   "updated": "2026-10-27", "summary": "Fictional demonstration, with no project commitments.",
                   "construction": "No construction schedule has been confirmed.",
                   "water": "No site-specific water information has been confirmed.",
                   "power": "No site-specific power information has been confirmed.",
                   "jobs": "No employment commitments have been made.",
                   "contact": "Demonstration only; no external contact route.", "owner": "Sample editor"},
        "sources": [{"id": "public-context", "title": "Public reference", "url": "https://example.com/context", "context": "General context only."}],
        "resources": [{"id": "faq", "title": "Questions to prepare", "topic": "Community", "summary": "Prepare local questions.", "sourceIds": ["public-context"]}],
        "comments": [{"text": "PRIVATE INTERNAL COMMENT"}],
    }


class PublicationTests(TestCase):
    def setUp(self):
        self.payload = sample()

    def html_outputs(self, page):
        return [self.client.get(page.url).content.decode(), self.client.get(page.url + "one-pager/").content.decode()]

    def test_new_draft_is_not_public_and_publish_exposes_both_routes(self):
        page, revision, _ = import_content(self.payload)
        self.assertEqual(self.client.get("/cedar-county/").status_code, 404)
        revision.publish()
        page.refresh_from_db()
        for url in [page.url, page.url + "one-pager/"]:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 200)
            self.assertContains(response, self.payload["market"]["construction"])
            self.assertNotContains(response, "PRIVATE INTERNAL COMMENT")

    def test_draft_isolation_publish_consistency_and_old_revision_recovery(self):
        page, original, _ = import_content(self.payload, publish=True)
        baseline = self.html_outputs(page)
        changed = copy.deepcopy(self.payload)
        changed["market"]["construction"] = "UNPUBLISHED SENTENCE: no confirmed schedule."
        _, draft, _ = import_content(changed)
        self.assertEqual(self.html_outputs(page), baseline)
        self.assertTrue(CommunityBriefPage.objects.get(pk=page.pk).has_unpublished_changes)
        draft.publish()
        for html in self.html_outputs(page):
            self.assertIn(changed["market"]["construction"], html)
        recovery = original.as_object().save_revision(previous_revision=original)
        recovery.publish(previous_revision=original)
        self.assertEqual(self.html_outputs(page), baseline)
        self.assertEqual(page.revisions.count(), 3)

    def test_invalid_reference_rolls_back_without_altering_published_page(self):
        page, _, _ = import_content(self.payload, publish=True)
        before = self.html_outputs(page)
        changed = copy.deepcopy(self.payload)
        changed["resources"][0]["sourceIds"] = ["missing-reference"]
        with self.assertRaises(ValidationError):
            import_content(changed, publish=True)
        self.assertEqual(self.html_outputs(page), before)
        self.assertEqual(page.revisions.count(), 1)

    def test_content_is_escaped_and_export_contract_omits_internal_comments(self):
        self.payload["market"]["construction"] = "<script>alert('demo')</script>"
        page, _, _ = import_content(self.payload, publish=True)
        for html in self.html_outputs(page):
            self.assertNotIn("<script>", html)
            self.assertIn("&lt;script&gt;", html)
        self.assertNotIn("comments", page.as_contract())
