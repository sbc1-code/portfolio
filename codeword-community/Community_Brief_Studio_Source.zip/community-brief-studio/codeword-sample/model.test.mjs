import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { FIELDS, initialState, updateField, requestReview, resolveComment, addComment, approveReview, publish, restoreDraft, publicRecord, exportHtml, restoreStored } from './model.mjs';

const seed = JSON.parse(readFileSync(new URL('./content.json', import.meta.url), 'utf8'));
const time = '2026-10-28T06:00:00.000Z';
function ready(state = initialState(seed)) {
  state = requestReview(state);
  for (const comment of state.comments) state = resolveComment(state, comment.id);
  return approveReview(state);
}

test('review can be requested with comments, but approval and publication are blocked', () => {
  const state = requestReview(initialState(seed));
  assert.equal(state.review.status, 'requested');
  assert.throws(() => approveReview(state), /Resolve every open comment/);
  assert.throws(() => publish(state, time), /Approve the current revision/);
  const forged = { ...ready(), comments: initialState(seed).comments };
  assert.throws(() => publish(forged, time), /Resolve every open comment/);
});

test('editing invalidates approval, including when restoring the same previous text', () => {
  const approved = ready();
  const edited = updateField(approved, 'construction', 'Work hours still require confirmation.');
  assert.equal(approved.review.status, 'approved');
  assert.equal(edited.review, null);
  assert.equal(edited.revision, 2);
  assert.throws(() => publish(edited, time), /Approve/);
  const forged = { ...approved, draft: { ...approved.draft, water: 'Changed outside the editor.' } };
  assert.throws(() => publish(forged, time), /changed after review/);
  assert.equal(updateField(approved, 'construction', approved.draft.construction).review, null);
});

test('empty and whitespace-only fields can be edited but cannot become divergent public outputs', () => {
  const labels = { summary: 'Summary', construction: 'Construction', water: 'Water', power: 'Power', jobs: 'Jobs and training', contact: 'Contact and updates' };
  for (const field of FIELDS) {
    for (const blank of ['', ' \n\t ']) {
      const original = initialState(seed);
      const editing = updateField(original, field, blank);
      assert.equal(editing.draft[field], blank);
      const message = `${labels[field]} needs text before review or publication.`;
      assert.throws(() => requestReview(editing), { message });

      // A previously stored approval must not bypass the same completeness gate.
      const fingerprint = JSON.stringify(['id', 'name', 'phase', 'updated', ...FIELDS].map(key => [key, editing.draft[key]]));
      const requested = { ...editing, review: { status: 'requested', fingerprint }, comments: editing.comments.map(comment => ({ ...comment, resolved: true })) };
      assert.throws(() => approveReview(requested), { message });
      const approved = { ...requested, review: { status: 'approved', fingerprint } };
      assert.throws(() => publish(approved, time), { message });

      const publicCopy = publicRecord(editing);
      assert.equal(publicCopy.market[field], seed.market[field]);
      assert.ok(publicCopy.market[field].trim());
      assert.ok(exportHtml(publicCopy).includes(seed.market[field]));
      assert.equal(editing.published.revision, 1);
      assert.equal(original.draft[field], seed.market[field]);
    }
  }
});

test('publishing isolates snapshots and moves the previous publication into history', () => {
  const before = ready();
  const state = publish(before, time);
  assert.equal(state.published.revision, 2);
  assert.equal(state.revision, 3);
  assert.equal(state.history[0].revision, 1);
  assert.equal(state.review, null);
  assert.equal(state.published.seed, false);
  assert.equal(before.published.revision, 1);
  state.draft.construction = 'Mutated draft';
  state.history[0].market.water = 'Mutated history';
  assert.notEqual(state.published.market.construction, 'Mutated draft');
  assert.notEqual(state.published.market.water, 'Mutated history');
  assert.notEqual(before.published.market.water, 'Mutated history');
});

test('restoring history changes only the draft and requires another review', () => {
  let state = updateField(initialState(seed), 'construction', 'An expanded explanation of unverified work hours.');
  state = publish(ready(state), time);
  const restored = restoreDraft(state, 1);
  assert.equal(restored.draft.construction, seed.market.construction);
  assert.equal(restored.published.market.construction, state.published.market.construction);
  assert.equal(restored.revision, 3);
  assert.equal(restored.review, null);
  assert.throws(() => publish(restored, time), /Approve/);
  assert.throws(() => restoreDraft(state, 999), /not available/);
});

test('public records explicitly exclude internal fields and use published copy only', () => {
  const state = initialState(seed);
  state.draft.summary = 'PRIVATE DRAFT';
  state.published.market.secret = 'PRIVATE EXTRA';
  state.sources[0].privateNote = 'PRIVATE SOURCE NOTE';
  const result = publicRecord(state);
  assert.deepEqual(Object.keys(result.market), ['id', 'name', 'phase', 'updated', ...FIELDS]);
  assert.equal(result.fictional, true);
  assert.ok(result.disclaimer.includes('Fictional'));
  assert.equal(result.market.summary, seed.market.summary);
  const output = JSON.stringify(result);
  for (const privateValue of ['PRIVATE DRAFT', 'PRIVATE EXTRA', 'PRIVATE SOURCE NOTE', 'demo role', seed.comments[0].text]) assert.ok(!output.includes(privateValue));
  result.market.water = 'Changed public result';
  assert.notEqual(state.published.market.water, result.market.water);
});

test('HTML escapes hostile text, disables connections, and rejects unsafe links', () => {
  const state = initialState(seed);
  const payload = '</p><script>alert("x")</script><img src=x onerror=alert(1)>';
  state.published.market.construction = payload;
  const record = publicRecord(state);
  const html = exportHtml(record);
  assert.ok(html.includes('&lt;script&gt;'));
  assert.ok(!html.includes('<script>'));
  assert.ok(!html.includes('<img'));
  assert.ok(html.includes("connect-src 'none'"));
  assert.ok(html.includes('size:letter'));
  assert.ok(html.includes('Fictional demonstration'));
  record.backgroundSources[0].url = 'javascript:alert(1)';
  assert.throws(() => exportHtml(record), /HTTPS/);
  assert.throws(() => publicRecord({ ...state, sources: [{ ...seed.sources[0], url: 'https://user:pass@example.com' }] }), /credentials/);
});

test('comments and action input validation produce readable errors', () => {
  const state = ready();
  const next = addComment(state, 'water', 'Please check the evidence.');
  assert.equal(next.review, null);
  assert.equal(next.comments.at(-1).resolved, false);
  assert.equal(state.comments.length, 1);
  assert.throws(() => addComment(state, 'owner', 'No'), /community topic/);
  assert.throws(() => resolveComment(state, 'missing'), /could not be found/);
  assert.throws(() => updateField(state, 'owner', 'No'), /editable/);
  assert.throws(() => updateField(state, 'water', 'x'.repeat(601)), /600 characters/);
  assert.throws(() => publish(state, 'not-a-time'), /ISO/);
});

test('storage round trips valid state and rejects corrupt or inconsistent data', () => {
  const saved = publish(ready(), time);
  const restored = restoreStored(JSON.stringify(saved), seed);
  assert.equal(restored.warning, null);
  assert.deepEqual(restored.state, saved);
  for (const invalid of ['{broken', '{}', JSON.stringify({ ...saved, schemaVersion: 99 }), JSON.stringify({ ...saved, revision: 500 }), JSON.stringify({ ...saved, published: { ...saved.published, market: { ...saved.published.market, water: 42 } } }), JSON.stringify({ ...saved, sources: [{ ...seed.sources[0], url: 'data:text/html,unsafe' }] })]) {
    const result = restoreStored(invalid, seed);
    assert.ok(result.warning);
    assert.deepEqual(result.state, initialState(seed));
  }
  const forged = { ...ready(), draft: { ...seed.market, jobs: 'A changed draft.' } };
  assert.ok(restoreStored(JSON.stringify(forged), seed).warning);
  assert.equal(restoreStored(null, seed).warning, null);
});

test('storage rejects incomplete published and historical snapshots but preserves incomplete drafts', () => {
  const saved = publish(ready(), time);
  for (const field of FIELDS) {
    for (const blank of ['', ' \n\t ']) {
      for (const location of ['published', 'history']) {
        const damaged = structuredClone(saved);
        const snapshot = location === 'published' ? damaged.published : damaged.history[0];
        snapshot.market[field] = blank;
        const recovered = restoreStored(JSON.stringify(damaged), seed);
        assert.ok(recovered.warning, `${location}.${field} must reject blank copy`);
        assert.deepEqual(recovered.state, initialState(seed));
      }
      const incomplete = updateField(saved, field, blank);
      const recovered = restoreStored(JSON.stringify(incomplete), seed);
      assert.equal(recovered.warning, null);
      assert.equal(recovered.state.draft[field], blank);
      assert.equal(recovered.state.review, null);
      assert.equal(publicRecord(recovered.state).market[field], saved.published.market[field]);
    }
  }
});

test('history retains 200 previous publications and safely reloads across the retention boundary', () => {
  let state = initialState(seed);
  for (const comment of state.comments) state = resolveComment(state, comment.id);
  for (let count = 1; count <= 200; count += 1) state = publish(approveReview(requestReview(state)), time);
  assert.equal(state.published.revision, 201);
  assert.equal(state.history.length, 200);
  assert.equal(state.history[0].revision, 200);
  assert.equal(state.history.at(-1).revision, 1);
  let recovered = restoreStored(JSON.stringify(state), seed);
  assert.equal(recovered.warning, null);
  assert.deepEqual(recovered.state, state);

  const atBoundary = state;
  for (let expectedRevision = 202; expectedRevision <= 203; expectedRevision += 1) {
    state = publish(approveReview(requestReview(state)), time);
    assert.equal(state.published.revision, expectedRevision);
    assert.equal(state.history.length, 200);
    assert.equal(state.history[0].revision, expectedRevision - 1);
    assert.equal(state.history.at(-1).revision, expectedRevision - 200);
    recovered = restoreStored(JSON.stringify(state), seed);
    assert.equal(recovered.warning, null);
    assert.deepEqual(recovered.state, state);
  }
  assert.equal(atBoundary.history.at(-1).revision, 1);
  assert.throws(() => restoreDraft(state, 1), /not available/);
  assert.equal(restoreDraft(state, 3).review, null);
  const restoredDraft = restoreDraft(state, 3);
  restoredDraft.draft.water = 'Changed restored draft';
  assert.notEqual(state.history.at(-1).market.water, restoredDraft.draft.water);
  assert.notEqual(state.published.market.water, restoredDraft.draft.water);
});
