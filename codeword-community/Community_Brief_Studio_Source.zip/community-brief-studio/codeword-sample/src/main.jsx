import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import seed from '../content.json';
import { FIELDS, initialState, updateField, requestReview, resolveComment, addComment, approveReview, publish, restoreDraft, publicRecord, exportHtml, restoreStored } from '../model.mjs';
import './styles.css';

const STORAGE_KEY = 'community-brief-studio-v1';
const labels = { summary: 'Summary', construction: 'Construction', water: 'Water', power: 'Power', jobs: 'Jobs & training', contact: 'Contact & updates' };
const fiction = 'Fictional sample. No real development or client is represented.';
const getView = () => ['published', 'about'].includes(location.hash.slice(1)) ? location.hash.slice(1) : 'workspace';

function Arrow() { return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15M13 6l6 6-6 6"/></svg>; }
function Check() { return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>; }
function load() {
  try { return restoreStored(localStorage.getItem(STORAGE_KEY), seed); }
  catch { return { state: initialState(seed), warning: 'Changes cannot be saved in this browser. Keep this page open to retain your work.' }; }
}
function download(name, text, type) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const link = document.createElement('a');
  link.href = url; link.download = name; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function draftRecord(state) {
  return publicRecord({ ...state, published: { revision: state.revision, market: state.draft, publishedAt: null, seed: false } });
}

function Header({ view }) {
  return <header className="app-header"><div className="header-inner">
    <a className="brand" href="#workspace">Community Brief Studio</a>
    <nav className="nav-links" aria-label="Main navigation">
      <a href="#workspace" aria-current={view === 'workspace' ? 'page' : undefined}>Editor</a>
      <a href="#published" aria-current={view === 'published' ? 'page' : undefined}>Published brief</a>
      <a href="#about" aria-current={view === 'about' ? 'page' : undefined}>How this was made</a>
    </nav>
  </div></header>;
}

function BriefDocument({ record, draft = false, original = false, full = false }) {
  return <article className="paper" aria-label={draft ? 'Draft community brief' : 'Published community brief'}>
    <div className="paper-toprule"/>
    <h2 className="paper-title">{record.market.name}</h2>
    <p className="paper-kind">Community brief</p>
    <p className="paper-fiction">{fiction}</p>
    <p className="paper-revision">{draft ? 'Unpublished draft' : original ? 'Original demo' : 'Published in this browser'} · Version {record.revision}</p>
    <section className="paper-summary"><h3>Summary</h3><p>{record.market.summary || 'Add a summary before review.'}</p></section>
    <div className="paper-topics">{FIELDS.filter(f => f !== 'summary').map(field => <section key={field}>
      <h3>{labels[field]}</h3><p>{record.market[field] || 'Add section text before review.'}</p>
    </section>)}</div>
    {full && <footer className="paper-sources"><h3>Background examples</h3><p>These sources illustrate topics only. They do not verify this fictional project or identify a client.</p><ul>{record.backgroundSources.map(s => <li key={s.id}><a href={s.url} target="_blank" rel="noreferrer">{s.title}</a></li>)}</ul><p>Workflow approval applies to sample copy, not to real project facts.</p></footer>}
  </article>;
}

function DraftPreview({ state }) {
  const [open, setOpen] = useState(false);
  return <aside className="preview-column" aria-label="Draft preview"><div className="preview-panel">
    <button className="preview-mobile-toggle secondary" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? 'Hide draft preview' : 'Show draft preview'}</button>
    <div className={`preview-content ${open ? 'mobile-open' : ''}`}>
      <h2>Draft preview</h2><p>Unpublished edits appear here.</p>
      <BriefDocument record={draftRecord(state)} draft/>
    </div>
  </div></aside>;
}

function Stepper({ stage, approved, onChoose }) {
  return <nav className="stepper" aria-label="Publishing steps">{['Edit brief', 'Review copy', 'Publish & share'].map((label, i) => <button key={label} className={`step-button ${stage === i ? 'active' : ''} ${approved && i === 1 ? 'complete' : ''}`} aria-current={stage === i ? 'step' : undefined} onClick={() => onChoose(i)}>
    <span className="step-number">{approved && i === 1 ? <Check/> : i + 1}</span><span className="step-label">{label}</span>
  </button>)}</nav>;
}

function EditStage({ state, act, selected, setSelected, onReview, focusField }) {
  const guidance = seed.resources.find(r => r.topic === selected);
  const open = state.comments.filter(c => !c.resolved);
  const count = state.draft[selected].length;
  return <section className="task-stage" aria-labelledby="edit-heading">
    <h2 id="edit-heading" className="stage-heading">Write the update</h2>
    <div className="section-nav" aria-label="Brief sections">{FIELDS.map(field => <button key={field} className={`section-choice ${selected === field ? 'active' : ''}`} aria-pressed={selected === field} onClick={() => setSelected(field)}>{labels[field]}{!state.draft[field].trim() && <span className="sr-only"> — needs text</span>}</button>)}</div>
    <label className="field-label" htmlFor="section-copy">{labels[selected]}</label>
    <textarea id="section-copy" ref={focusField} className="editor-textarea" value={state.draft[selected]} maxLength={selected === 'summary' ? 400 : 600} onChange={e => act(s => updateField(s, selected, e.target.value), state.review?.status === 'approved' ? 'Your edit cleared approval. Review the updated draft before publishing.' : '')}/>
    <p className="field-count">{count} / {selected === 'summary' ? 400 : 600} characters</p>
    <section className="guidance" aria-labelledby="guidance-heading"><h3 id="guidance-heading">Section guidance</h3><p>{guidance?.summary || 'Explain what the brief is for in plain language. Keep unconfirmed information clearly marked and avoid promises the project has not verified.'}</p></section>
    <div className="stage-actions"><p className="action-note">{open.length ? `${open.length === 1 ? 'One comment is' : `${open.length} comments are`} waiting for review.` : 'Your edits stay private until you publish.'}</p><div className="action-buttons">
      <button className="secondary" onClick={() => setSelected(FIELDS[(FIELDS.indexOf(selected) + 1) % FIELDS.length])}>Next section</button>
      <button className="primary" onClick={onReview}>Review draft <Arrow/></button>
    </div></div>
  </section>;
}

function ReviewItem({ comment, state, act, onEdit }) {
  return <li className={`review-item ${comment.resolved ? 'resolved' : ''}`}>
    <div className="review-title"><h3>{labels[comment.section]}</h3><span className="comment-status">{comment.resolved ? 'Addressed' : 'Open comment'}</span></div>
    <p className="comment-text">{comment.text}</p>
    {!comment.resolved && <><div className="current-copy"><span className="small-label">Current wording</span><p>{state.draft[comment.section] || 'This section is empty.'}</p></div><div className="inline-actions"><button className="secondary" onClick={() => onEdit(comment.section)}>Edit section</button><button className="secondary" onClick={() => act(s => resolveComment(s, comment.id), 'Comment marked addressed. Read the current draft before approving it.')}>Mark addressed</button></div></>}
  </li>;
}

function ReviewStage({ state, act, onEdit, onBack, onApprove }) {
  const [section, setSection] = useState('construction');
  const [text, setText] = useState('');
  const open = state.comments.filter(c => !c.resolved);
  const addressed = state.comments.filter(c => c.resolved);
  return <section className="task-stage" aria-labelledby="review-heading">
    <h2 id="review-heading" className="stage-heading">Resolve feedback</h2>
    <p className="stage-intro">{open.length ? `${open.length} open ${open.length === 1 ? 'comment' : 'comments'}. Address ${open.length === 1 ? 'it' : 'them'} before approving this draft.` : 'All comments are addressed. Read the draft preview, then approve this version.'}</p>
    {open.length > 0 && <ul className="review-list">{open.map(c => <ReviewItem key={c.id} comment={c} state={state} act={act} onEdit={onEdit}/>)}</ul>}
    {addressed.length > 0 && <details className="addressed-comments"><summary>{addressed.length} addressed {addressed.length === 1 ? 'comment' : 'comments'}</summary><ul className="review-list">{addressed.map(c => <ReviewItem key={c.id} comment={c} state={state} act={act} onEdit={onEdit}/>)}</ul></details>}
    <details className="add-comment"><summary>Add a review comment</summary><form className="comment-form" onSubmit={e => { e.preventDefault(); if (act(s => addComment(s, section, text), 'Review comment added.')) setText(''); }}>
      <label>Section<select value={section} onChange={e => setSection(e.target.value)}>{FIELDS.map(f => <option key={f} value={f}>{labels[f]}</option>)}</select></label>
      <label>Comment<textarea value={text} maxLength={1000} onChange={e => setText(e.target.value)} placeholder="Describe the wording that needs attention." required/></label>
      <button className="secondary" type="submit">Add comment</button>
    </form></details>
    <div className="stage-actions"><p className="action-note">{open.length ? 'Resolve the open feedback to continue.' : 'Approval applies to this exact draft.'}</p><div className="action-buttons"><button className="secondary" onClick={onBack}>Back to editing</button><button className="primary" disabled={open.length > 0} onClick={onApprove}>Approve this draft <Arrow/></button></div></div>
    <p className="scope-note">Local review simulation. Approval does not verify real project facts or authenticate a reviewer.</p>
  </section>;
}

function PublishStage({ state, onReview, onPublish }) {
  const approved = state.review?.status === 'approved';
  return <section className="task-stage" aria-labelledby="publish-heading">
    <h2 id="publish-heading" className="stage-heading">{approved ? 'Ready to publish' : 'This draft needs review'}</h2>
    <p className="stage-intro">{approved ? 'Publish one version for the web page and printable brief. Your current published version will stay in Earlier versions.' : 'Address the feedback and approve the current wording before publishing.'}</p>
    <div className={`approval-summary ${approved ? '' : 'pending'}`}>{approved && <Check/>}<div><h3>{approved ? `Draft v${state.revision} approved` : 'Approval required'}</h3><p>{approved ? 'Any further edit will require a fresh review.' : 'The published brief stays unchanged while you work.'}</p></div></div>
    <ul className="release-checks"><li>Web page and downloads use the same snapshot.</li><li>Review comments and content-owner details stay private.</li><li>This publishes only in your browser’s local demo.</li></ul>
    <div className="stage-actions"><div className="action-buttons"><button className="secondary" onClick={onReview}>Back to review</button><button className="primary" disabled={!approved} onClick={onPublish}>Publish brief <Arrow/></button></div></div>
    <p className="scope-note">{fiction} No data is sent to Codeword or a live client system.</p>
  </section>;
}

function Workspace({ state, act, saved }) {
  const [stage, setStage] = useState(0);
  const [selected, setSelected] = useState('construction');
  const focusField = useRef(null);
  const stageHeading = useRef(null);
  function move(next) { setStage(next); requestAnimationFrame(() => stageHeading.current?.focus({ preventScroll: true })); }
  function review() {
    const missing = FIELDS.find(f => !state.draft[f].trim());
    if (missing) { setSelected(missing); setStage(0); act(requestReview, ''); requestAnimationFrame(() => focusField.current?.focus()); return; }
    if (state.review || act(requestReview, '')) move(1);
  }
  function edit(field) { setSelected(field); move(0); requestAnimationFrame(() => focusField.current?.focus()); }
  function approve() {
    if (act(s => approveReview(s.review?.status === 'requested' ? s : requestReview(s)), 'This draft is approved. Publish it when you are ready.')) move(2);
  }
  function publishBrief() {
    if (act(s => publish(s, new Date().toISOString()), 'Published. The page and downloads now use the same version.')) location.hash = 'published';
  }
  return <main id="main" className="studio-shell"><div className="task-column">
    <div className="page-heading"><h1 ref={stageHeading} tabIndex={-1}>Cedar County community brief</h1><p className="intro-copy">Turn reviewed copy into a matching web page and printable brief.</p><p className="fiction-note">Fictional sample · Changes stay in this browser.</p></div>
    <Stepper stage={stage} approved={state.review?.status === 'approved'} onChoose={next => next === 1 ? review() : move(next)}/>
    <div className="version-status"><strong>Editing draft v{state.revision}</strong><span>Published v{state.published.revision} stays unchanged.</span></div>
    {stage === 0 && <EditStage state={state} act={act} selected={selected} setSelected={setSelected} onReview={review} focusField={focusField}/>}
    {stage === 1 && <ReviewStage state={state} act={act} onEdit={edit} onBack={() => move(0)} onApprove={approve}/>}
    {stage === 2 && <PublishStage state={state} onReview={review} onPublish={publishBrief}/>}
    <p className="saved-status" role="status">{saved ? 'Saved in this browser' : 'Session only — browser storage unavailable'}</p>
  </div><DraftPreview state={state}/></main>;
}

function PublishedView({ state, act, downloadPublic }) {
  const record = publicRecord(state);
  return <main id="main" className="published-shell"><section className="published-tools">
    <h1>{state.published.seed ? 'The original published demo' : 'Your brief is published'}</h1>
    <p className="intro-copy">The web page and printable brief use the same version.</p>
    <p className="release-success"><Check/>{state.published.seed ? 'Original demo' : `Published v${record.revision} in this browser`}</p>
    <p className="fiction-note">Fictional sample. Other visitors start with the original demo.</p>
    <div className="published-actions"><button className="primary" onClick={downloadPublic}>Download printable brief</button><button className="secondary" onClick={() => download(`cedar-county-revision-${record.revision}.json`, JSON.stringify(record, null, 2), 'application/json')}>Download public JSON</button><a className="text-button" href="#workspace">Keep editing</a></div>
    <section className="history-list"><h2>Earlier versions</h2>{state.history.length ? state.history.map(item => <div className="history-item" key={item.revision}><span>Version {item.revision}{item.seed ? ' · Original demo' : ''}</span><button className="secondary" onClick={() => { if (act(s => restoreDraft(s, item.revision), `Version ${item.revision} copied into draft v${state.revision}. The published brief is unchanged.`)) location.hash = 'workspace'; }}>Use as a new draft</button></div>) : <p>Publish a new version to keep the previous one here.</p>}<p className="scope-note">Restoring a version changes the draft. Published content stays unchanged. The latest 200 earlier versions are retained.</p></section>
    <details className="share-details"><summary>What gets shared?</summary><p>The printable HTML file and JSON contain only the published brief and public background links. Internal comments, content-owner details and unpublished edits are excluded.</p><p>Open the HTML file to print or save it as PDF. Final pagination depends on the amount of copy and print settings.</p><p>This is a local simulation. Other visitors do not see your edits, and nothing is sent to an external system.</p></details>
  </section><div className="published-document"><BriefDocument record={record} original={state.published.seed} full/></div></main>;
}

function AboutView({ onReset }) {
  return <main id="main" className="about-shell"><h1>How this was made</h1><p className="intro-copy">An independent production sample for Codeword’s Strategic Communications &amp; Web Project Manager role.</p>
    <section className="about-section"><h2>Try one complete release</h2><ol><li>Edit Construction to say what a dated work notice should include.</li><li>Open Review copy, address the construction comment and approve the draft.</li><li>Publish the brief, then compare the page with its printable HTML and JSON.</li><li>Use an earlier version as a new draft. The published copy remains unchanged.</li></ol><a className="button primary" href="#workspace">Open editor <Arrow/></a></section>
    <section className="about-section"><h2>What is implemented</h2><p>The browser app supports editing, section guidance, feedback, review tied to the current copy, publication snapshots, earlier-version recovery and standalone exports. Public outputs read the same published record.</p><p>A separate actual local Wagtail 8.0.1 proof imports the same content into a Page model and exercises draft isolation, coordinated output publication and recovery. The browser app and Wagtail database are separate implementations. <a href="./cms-proof/publication-proof.json" target="_blank" rel="noreferrer">Inspect the CMS evidence</a>.</p><p><a href="./Community_Brief_Studio_Source.zip" download>Download the source and local CMS proof</a>.</p></section>
    <section className="about-section"><h2>Direction and assistance</h2><p>Sebastian selected the role, directed the concept and reviewed the working app. He approved this revised version for publication on October 27, 2026.</p><p>ChatGPT (Codex) assisted with research, copy, design, implementation and checks. OpenAI Image Gen supplied visual references. Interface text and controls are native HTML, CSS and React; no live model runs in this app.</p></section>
    <section className="about-section"><h2>Scope and sources</h2><p>{fiction} Microsoft and AWS material informed the topics only. No jobs, investment, water-use, energy or other local outcomes are claimed. The sample does not establish prior professional Wagtail experience or a live CMS deployment.</p><p>There is no inquiry endpoint, analytics, messaging, identity system or authenticated approval. Data stays in this browser. Do not enter private client material.</p><ul><li><a href="https://job-boards.greenhouse.io/codeword/jobs/5444206008" target="_blank" rel="noreferrer">Official Codeword role</a></li><li><a href="https://www.codewordagency.com/our-work/" target="_blank" rel="noreferrer">Codeword’s public work</a></li>{seed.sources.map(s => <li key={s.id}><a href={s.url} target="_blank" rel="noreferrer">{s.title}</a> — topic examples only</li>)}</ul></section>
    <section className="about-section"><h2>Start again</h2><p>Reset replaces your local edits, comments and publication history with the original fictional sample.</p><button className="secondary" onClick={onReset}>Reset this demo</button></section>
  </main>;
}

function App() {
  const [loaded] = useState(load);
  const [state, setState] = useState(loaded.state);
  const [storageWarning, setStorageWarning] = useState(loaded.warning);
  const [saved, setSaved] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [view, setView] = useState(getView);
  const resetDialog = useRef(null);
  useEffect(() => { const handler = () => { setView(getView()); window.scrollTo(0, 0); }; window.addEventListener('hashchange', handler); return () => window.removeEventListener('hashchange', handler); }, []);
  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); setSaved(true); } catch { setSaved(false); setStorageWarning('Browser storage could not save this change. Keep the page open to retain your work.'); } }, [state]);
  function act(transform, message) {
    try { setState(transform(state)); setError(''); setNotice(message); return true; }
    catch (e) { setError(e.message); setNotice(''); return false; }
  }
  function downloadPublic() {
    try { const record = publicRecord(state); download(`cedar-county-revision-${record.revision}.html`, exportHtml(record), 'text/html'); setNotice(`Downloaded published version ${record.revision}. Open the HTML file to print or save as PDF.`); setError(''); }
    catch (e) { setError(e.message); }
  }
  return <><a className="skip-link" href="#main">Skip to content</a><Header view={view}/>
    {storageWarning && <div className="notice warning" role="status">{storageWarning}</div>}
    {(notice || error) && <div className={`notice ${error ? 'error' : ''}`} role={error ? 'alert' : 'status'}><span>{error || notice}</span><button className="text-button" aria-label="Dismiss message" onClick={() => { setError(''); setNotice(''); }}>Dismiss</button></div>}
    {view === 'workspace' ? <Workspace state={state} act={act} saved={saved}/> : view === 'published' ? <PublishedView state={state} act={act} downloadPublic={downloadPublic}/> : <AboutView onReset={() => resetDialog.current.showModal()}/>}
    <footer className="app-footer">Independent application sample by Sebastian Becerra · Fictional content, local workflow.</footer>
    <dialog ref={resetDialog} className="reset-dialog"><h2>Reset this demo?</h2><p>Your edits, comments and publication history will be replaced with the original fictional sample.</p><div className="inline-actions"><button className="secondary" onClick={() => resetDialog.current.close()}>Keep my work</button><button className="primary" onClick={() => { setState(initialState(seed)); setNotice('Original demonstration restored.'); setError(''); resetDialog.current.close(); }}>Reset demo</button></div></dialog>
  </>;
}

createRoot(document.getElementById('root')).render(<App/>);
