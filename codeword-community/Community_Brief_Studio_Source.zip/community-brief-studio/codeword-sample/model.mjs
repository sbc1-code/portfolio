export const FIELDS = Object.freeze(['summary', 'construction', 'water', 'power', 'jobs', 'contact']);

const PUBLIC_FIELDS = Object.freeze(['id', 'name', 'phase', 'updated', ...FIELDS]);
const DISCLAIMER = 'Fictional demonstration — no real development or client is represented.';
const MAX_LENGTH = { id: 80, name: 120, phase: 180, updated: 10, summary: 400, construction: 600, water: 600, power: 600, jobs: 600, contact: 600, owner: 180 };
const MAX_HISTORY = 200;
const clone = value => structuredClone(value);
const fail = message => { throw new Error(message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);

function string(value, label, max, allowEmpty = false) {
  if (typeof value !== 'string' || (!allowEmpty && !value.trim())) fail(`${label} must contain text.`);
  if (value.length > max) fail(`${label} must be ${max} characters or fewer.`);
  return value;
}

function market(value, includeOwner = true) {
  if (!object(value)) fail('The community record is missing or invalid.');
  const result = {};
  for (const key of PUBLIC_FIELDS) result[key] = string(value[key], key, MAX_LENGTH[key], FIELDS.includes(key));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(result.updated) || Number.isNaN(Date.parse(`${result.updated}T00:00:00Z`))) fail('The update date must use YYYY-MM-DD.');
  if (includeOwner) result.owner = string(value.owner, 'Content owner', MAX_LENGTH.owner);
  return result;
}

function safeUrl(value) {
  string(value, 'Background source URL', 2048);
  let url;
  try { url = new URL(value); } catch { fail('Use a complete HTTPS URL for each background source.'); }
  if (url.protocol !== 'https:' || url.username || url.password) fail('Background source links must use HTTPS without credentials.');
  return url.href;
}

function sources(value) {
  if (!Array.isArray(value) || value.length > 20) fail('The background source list is invalid.');
  const seen = new Set();
  return value.map(source => {
    if (!object(source)) fail('A background source is invalid.');
    const id = string(source.id, 'Source ID', 100);
    if (seen.has(id)) fail('Background source IDs must be unique.');
    seen.add(id);
    return {
      id,
      title: string(source.title, 'Source title', 240),
      url: safeUrl(source.url),
      context: string(source.context, 'Source context', 800),
    };
  });
}

function comments(value) {
  if (!Array.isArray(value) || value.length > 100) fail('The review comments are invalid.');
  const seen = new Set();
  return value.map(comment => {
    if (!object(comment)) fail('A review comment is invalid.');
    const id = string(comment.id, 'Comment ID', 100);
    if (seen.has(id) || !FIELDS.includes(comment.section) || typeof comment.resolved !== 'boolean') fail('A review comment has invalid details.');
    seen.add(id);
    return { id, section: comment.section, text: string(comment.text, 'Comment', 1000), resolved: comment.resolved };
  });
}

function fingerprint(value) {
  return JSON.stringify(PUBLIC_FIELDS.map(key => [key, value[key]]));
}

function requireCompleteCopy(value) {
  const labels = { summary: 'Summary', construction: 'Construction', water: 'Water', power: 'Power', jobs: 'Jobs and training', contact: 'Contact and updates' };
  for (const field of FIELDS) {
    if (typeof value[field] !== 'string' || !value[field].trim()) fail(`${labels[field]} needs text before review or publication.`);
  }
}

function clearComments(state) {
  if (state.comments.some(comment => !comment.resolved)) fail('Resolve every open comment before approving or publishing.');
}

function currentReview(state, status) {
  if (!state.review || state.review.status !== status) fail(status === 'approved' ? 'Approve the current revision before publishing.' : 'Request a review of the current revision first.');
  if (state.review.fingerprint !== fingerprint(state.draft)) fail('This revision changed after review. Request a new review.');
}

export function initialState(seed) {
  if (!object(seed) || seed.version !== 1) fail('The sample content version is invalid.');
  const draft = market(seed.market);
  return {
    schemaVersion: 1,
    draft,
    revision: 2,
    review: null,
    comments: comments(seed.comments ?? []),
    published: { revision: 1, market: clone(draft), publishedAt: null, seed: true },
    history: [],
    sources: sources(seed.sources ?? []),
  };
}

export function updateField(state, field, value) {
  if (!FIELDS.includes(field)) fail('Choose an editable community topic.');
  string(value, field, MAX_LENGTH[field], true);
  return { ...state, draft: { ...state.draft, [field]: value }, review: null };
}

export function requestReview(state) {
  market(state.draft);
  requireCompleteCopy(state.draft);
  return { ...state, review: { status: 'requested', fingerprint: fingerprint(state.draft) } };
}

export function resolveComment(state, id) {
  if (!state.comments.some(comment => comment.id === id)) fail('That review comment could not be found.');
  return { ...state, comments: state.comments.map(comment => comment.id === id ? { ...comment, resolved: true } : comment) };
}

export function addComment(state, section, text) {
  if (!FIELDS.includes(section)) fail('Choose a community topic for the comment.');
  string(text, 'Comment', 1000);
  if (state.comments.length >= 100) fail('This sample supports up to 100 review comments.');
  let number = state.comments.length + 1;
  while (state.comments.some(comment => comment.id === `comment-${number}`)) number += 1;
  return { ...state, review: null, comments: [...state.comments, { id: `comment-${number}`, section, text: text.trim(), resolved: false }] };
}

export function approveReview(state) {
  requireCompleteCopy(state.draft);
  currentReview(state, 'requested');
  clearComments(state);
  return { ...state, review: { status: 'approved', fingerprint: fingerprint(state.draft) } };
}

export function publish(state, nowISO) {
  requireCompleteCopy(state.draft);
  currentReview(state, 'approved');
  clearComments(state);
  market(state.draft);
  string(nowISO, 'Publication time', 40);
  if (!/^\d{4}-\d{2}-\d{2}T/.test(nowISO) || Number.isNaN(Date.parse(nowISO))) fail('Provide a valid ISO publication time.');
  const snapshot = market(state.draft);
  return {
    ...state,
    published: { revision: state.revision, market: clone(snapshot), publishedAt: nowISO, seed: false },
    history: [state.published, ...state.history].slice(0, MAX_HISTORY).map(clone),
    revision: state.revision + 1,
    review: null,
    draft: clone(snapshot),
  };
}

export function restoreDraft(state, historyRevision) {
  const previous = state.history.find(item => item.revision === historyRevision);
  if (!previous) fail('That published revision is not available in history.');
  return { ...state, draft: market(previous.market), review: null };
}

export function publicRecord(state) {
  if (!state.published) fail('No community revision is available.');
  return {
    fictional: true,
    disclaimer: DISCLAIMER,
    revision: state.published.revision,
    publishedAt: state.published.publishedAt,
    market: market(state.published.market, false),
    backgroundSources: sources(state.sources ?? []),
  };
}

const escapeHtml = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));

export function exportHtml(record) {
  if (!object(record) || record.fictional !== true || !Number.isInteger(record.revision) || record.revision < 1) fail('A valid fictional public record is required for export.');
  const content = market(record.market, false);
  const background = sources(record.backgroundSources ?? []);
  const labels = { construction: 'Construction', water: 'Water', power: 'Power', jobs: 'Jobs and training', contact: 'Contact and updates' };
  const sections = FIELDS.filter(field => field !== 'summary').map(field => `<section><h2>${labels[field]}</h2><p>${escapeHtml(content[field])}</p></section>`).join('');
  const links = background.map(source => `<li><a href="${escapeHtml(source.url)}" rel="noopener noreferrer">${escapeHtml(source.title)}</a></li>`).join('');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; connect-src 'none'; object-src 'none'"><title>${escapeHtml(content.name)} — community brief</title>
<style>@page{size:letter;margin:.5in}*{box-sizing:border-box}body{font:10pt/1.35 Arial,sans-serif;color:#161616;max-width:7.5in;margin:0 auto}header{border-bottom:3px solid #161616;padding-bottom:12px}.label{font-weight:bold;background:#f0f0f0;padding:8px}h1{font-size:23pt;line-height:1.1;margin:14px 0 8px}h2{font-size:11pt;margin:0 0 5px}p{margin:0 0 8px;overflow-wrap:anywhere}.meta{font-size:9pt}.topics{display:grid;grid-template-columns:1fr 1fr;gap:14px 20px;margin:18px 0}section{break-inside:avoid}footer{border-top:1px solid #888;padding-top:8px;font-size:8pt}ul{padding-left:15px;margin:5px 0}a{color:inherit;overflow-wrap:anywhere}@media print{body{margin:0}a{text-decoration:none}.topics{gap:10px 18px}}</style></head>
<body><header><p class="label">${escapeHtml(DISCLAIMER)}</p><h1>${escapeHtml(content.name)} community brief</h1><p>${escapeHtml(content.summary)}</p><p class="meta">${escapeHtml(content.phase)} · Updated ${escapeHtml(content.updated)} · Demo revision ${record.revision}</p></header><main class="topics">${sections}</main><footer><strong>Background examples from other organizations</strong><p>These sources illustrate community topics. They do not verify this fictional project or identify a client.</p><ul>${links}</ul><p>Workflow approval applies to sample copy, not to the accuracy of a real project.</p></footer></body></html>`;
}

function storedSnapshot(value) {
  if (!object(value) || !Number.isInteger(value.revision) || value.revision < 1 || typeof value.seed !== 'boolean') fail('The saved publication is invalid.');
  if (value.publishedAt !== null && (typeof value.publishedAt !== 'string' || Number.isNaN(Date.parse(value.publishedAt)))) fail('The saved publication time is invalid.');
  if ((!value.seed && value.publishedAt === null) || (value.seed && value.publishedAt !== null)) fail('The saved publication status is invalid.');
  const savedMarket = market(value.market);
  requireCompleteCopy(savedMarket);
  return { revision: value.revision, market: savedMarket, publishedAt: value.publishedAt, seed: value.seed };
}

export function restoreStored(raw, seed) {
  const fallback = initialState(seed);
  if (raw === null || raw === undefined || raw === '') return { state: fallback, warning: null };
  try {
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!object(parsed) || parsed.schemaVersion !== 1 || !Number.isInteger(parsed.revision) || parsed.revision < 2) fail('The saved draft version is invalid.');
    if (!Array.isArray(parsed.history) || parsed.history.length > MAX_HISTORY) fail('The saved publication history is invalid.');
    const draft = market(parsed.draft);
    const published = storedSnapshot(parsed.published);
    const history = parsed.history.map(storedSnapshot);
    if (parsed.revision !== published.revision + 1) fail('The saved revision numbers are inconsistent.');
    const seen = new Set([published.revision]);
    let previous = published.revision;
    for (const item of history) {
      if (seen.has(item.revision) || item.revision >= previous) fail('The saved history order is invalid.');
      seen.add(item.revision);
      previous = item.revision;
    }
    const checkedComments = comments(parsed.comments);
    let review = null;
    if (parsed.review !== null) {
      if (!object(parsed.review) || !['requested', 'approved'].includes(parsed.review.status) || parsed.review.fingerprint !== fingerprint(draft)) fail('The saved review no longer matches the draft.');
      if (parsed.review.status === 'approved' && checkedComments.some(item => !item.resolved)) fail('The saved approval contains open comments.');
      review = { status: parsed.review.status, fingerprint: parsed.review.fingerprint };
    }
    return {
      state: { schemaVersion: 1, draft, revision: parsed.revision, review, comments: checkedComments, published, history, sources: sources(parsed.sources) },
      warning: null,
    };
  } catch {
    return { state: fallback, warning: 'The saved demo could not be restored safely. The original sample has been loaded.' };
  }
}
